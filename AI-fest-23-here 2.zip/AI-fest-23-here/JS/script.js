const daysHTML = document.querySelector("#number-of-days")
const hoursHTML = document.querySelector("#number-of-hours")
const minutesHTML = document.querySelector("#number-of-minutes")
const secondsHTML = document.querySelector("#number-of-seconds")

const AIFestTime = new Date("2023-06-17").getTime()
const today = new Date().getTime
const diff = AIFestTime - today / 1000

setInterval(() => {
    const today = new Date().getTime();
    let diff = (AIFestTime - today) / 1000;
    let days = Math.floor(diff / 60 / 60 / 24);
    days < 10 ? (days = "0" + days) : null;
    let hours = Math.floor(diff / 60 / 60) - days * 24;
    hours < 10 ? (hours = "0" + hours) : null;
    let minutes = Math.floor(diff / 60) - days * 24 * 60 - hours * 60;
    minutes < 10 ? (minutes = "0" + minutes) : null;
    let seconds =
      Math.floor(diff) - days * 24 * 60 * 60 - hours * 60 * 60 - minutes * 60;
    seconds < 10 ? (seconds = "0" + seconds) : null;
    daysHTML.innerHTML = days;
    hoursHTML.innerHTML = hours;
    minutesHTML.innerHTML = minutes;
    secondsHTML.innerHTML = seconds;
  }, 1000);

  let navLinks = document.querySelector('.nav-writings')
  let navLinksadder = document.querySelector('.three-lines')
  let navLinksremover = document.querySelector('.xmark')
  var scrollToTop = document.querySelector(".nav-writings > p:nth-child(1)");
  var scrollToAbout = document.querySelector(".nav-writings > p:nth-child(2)");
  var scrollToMentors = document.querySelector(".nav-writings > p:nth-child(3)");
  var scrollToFooter = document.querySelector(".nav-writings > p:nth-child(4)");

  let homeSection = document.querySelector('.hero-section')
  let aboutSection = document.querySelector('.about-section')
  let mentorsSection = document.querySelector('.workshops-section')
  let footerSection = document.querySelector('footer')

  

  // show the button when the user scrolls down 20 pixels from the top of the page
  window.onscroll = function() {
    scrollToTop.classList.remove("colored1")
      scrollToAbout.classList.remove("colored2")
      scrollToMentors.classList.remove("colored3")
      scrollToFooter.classList.remove("colored4")

    if (document.body.scrollTop >= homeSection.offsetHeight + aboutSection.offsetHeight + (mentorsSection.offsetHeight / 2) - 63 || document.documentElement.scrollTop > homeSection.offsetHeight + aboutSection.offsetHeight + (mentorsSection.offsetHeight / 2) - 63
         || window.innerHeight + window.pageYOffset >= document.documentElement.offsetHeight) {

      scrollToTop.classList.remove("colored1")
      scrollToAbout.classList.remove("colored2")
      scrollToMentors.classList.remove("colored3")
      scrollToFooter.classList.add("colored4")

    } else if (document.body.scrollTop > homeSection.offsetHeight + aboutSection.offsetHeight - 63 || document.documentElement.scrollTop > homeSection.offsetHeight + aboutSection.offsetHeight - 63){
      scrollToTop.classList.remove("colored1")
      scrollToAbout.classList.remove("colored2")
      scrollToMentors.classList.add("colored3")
      scrollToFooter.classList.remove("colored4")
    } else if (document.body.scrollTop > homeSection.offsetHeight - 63 || document.documentElement.scrollTop > homeSection.offsetHeight - 63){
      scrollToTop.classList.remove("colored1")
      scrollToAbout.classList.add("colored2")
      scrollToMentors.classList.remove("colored3")
      scrollToFooter.classList.remove("colored4")
    } else {
      scrollToTop.classList.add("colored1")
      scrollToAbout.classList.remove("colored2")
      scrollToMentors.classList.remove("colored3")
      scrollToFooter.classList.remove("colored4")
    }
    
  };

  scrollToTop.onclick = function() {
    document.body.scrollTop = 130; 
    document.documentElement.scrollTop = 130; 
  };

  scrollToAbout.onclick = function() {
    document.body.scrollTop = homeSection.offsetHeight - 62; 
    document.documentElement.scrollTop = homeSection.offsetHeight - 62; 
  };

  scrollToMentors.onclick = function() {
    document.body.scrollTop = homeSection.offsetHeight + aboutSection.offsetHeight - 53; 
    document.documentElement.scrollTop = homeSection.offsetHeight + aboutSection.offsetHeight - 53; 
  };

  scrollToFooter.onclick = function() {
    document.body.scrollTop = homeSection.offsetHeight + aboutSection.offsetHeight + footerSection.offsetHeight + 500; 
    document.documentElement.scrollTop = homeSection.offsetHeight + aboutSection.offsetHeight + footerSection.offsetHeight + 500; 
  };

  function changeIcon(){
    navLinks.classList.toggle('visible-element')
    navLinksadder.classList.toggle('hidden-element')
    navLinksremover.classList.toggle('visible-element')

}