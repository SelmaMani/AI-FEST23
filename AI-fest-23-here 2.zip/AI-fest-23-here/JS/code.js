function generateCode() {
        const timestamp = Math.floor(Date.now()); // Unix timestamp
        const randomNum = Math.floor(Math.random() * 10000); // Random number between 0 and 9999
        const code = `${timestamp}${randomNum}`;
        return code;
      }
      
      // Example usage
      const generatedCode = generateCode();
      console.log(generatedCode);